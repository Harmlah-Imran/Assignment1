#include <iostream>
using namespace std;
int main()
{
	int i= 1;
	while (i <= 5)//loop for printing numbers
	{
		int a = 1;
		while (a <= i)
		{
			cout << a;
			a++;
		}
		cout << endl;// Move to the next line after each row
		i++;
	}
	int rows = 5; // Number of rows for the second pattern
	for (int i = 1; i <= rows; i++) {
		for (int j = 1; j <= rows - i; j++) {   // Print spaces 
			cout << "  ";
		}
		for (int k = 1; k <= i; k++) {
			cout << "* ";
		}
		cout << endl;   // Move to the next line after each row
	}
		return 0;
	}
