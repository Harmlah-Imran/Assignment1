#include <iostream>
using namespace std;
int main()
{
    cout << "*****BANK ACCOUNT MANAGEMENT SYSTEM*****" << endl;
    const int PIN_CODE = 1234;//predefined code of the account
    int enteredPin, choice, deposit, withdraw;
    double balance = 1000.0;//inital balance of the account
    bool account_creation = false;//to keep track if the account is created or not
    while (true)//while loop with true condition so that user returns to main menu until he chooses to exit
    {
          cout << "1. Create Account" << endl;
          cout << "2. Deposit Money" << endl;
          cout << "3. Withdraw Money" << endl;
          cout << "4. Check Balance" << endl;
          cout << "5. Exit" << endl;
        cin >> choice;
        if (choice == 1) {
            if (!account_creation)
            {
                cout << "Account created successfully"<<endl;
                cout << "Your initial balance is:1000.0" << endl;
                account_creation = true;//make the condition true when the account is created
            }
            else {
                cout << "Account already exists"<<endl;
            }
        }
        else if (choice == 2) {
            if (account_creation) {
                cout << "Enter the Pin code: ";
                cin >> enteredPin;
                if (enteredPin == PIN_CODE) {
                    cout << "Enter the amount that you want to deposit: "<<endl;
                    cin >> deposit;
                    if (deposit > 0) {//checking if deposited amount is valid
                        balance=balance + deposit;//adding the deposited amount to current balance
                        cout << "Amount Deposit successful" << endl;
                        cout<< "Your new balance is:" << balance << endl;
                    }
                    else {
                        cout << "Invalid amount<<endl";
                    }
                }
                else {
                    cout << "Incorrect Pin"<<endl;
                }
            }
            else {
                cout << "You do not have an account"<<endl;//to make sure that acc is created first
            }
        }
        else if (choice == 3) {
            if (account_creation) {
                cout << "Enter the Pin code:";
                cin >> enteredPin;
                if (enteredPin == PIN_CODE) {
                    cout << "Enter the amount that you want to withdraw: "<<endl;
                    cin >> withdraw;
                    if (withdraw > 0 && withdraw <= balance) {//checking if withdrawal amount is valid
                        balance = balance - withdraw;//subtracting the withdrawal amount to create a new balance
                        cout << "Withdrawal successfull Your new balance is:" << balance << endl;
                    }
                    else {
                        cout << "Invalid amount"<<endl;
                    }
                }
                else {
                    cout << "Incorrect Pin"<<endl;
                }
            }
            else {
                cout << "You do not have an account"<<endl;
            }
        }
        else if (choice == 4) {
            if (account_creation) {
                cout << "Enter the PIN code: ";
                cin >> enteredPin;
                if (enteredPin == PIN_CODE) {
                    cout << "Your balance is:" << balance << endl;
                }
                else {
                    cout << "Incorrect PIN"<<endl;
                }
            }
            else 
                cout << "You do not have  an account"<<endl;

        }
        else if (choice == 5) {
            cout << "Exited"<<endl;
            return 0;
        }
        else {
            cout << "Invalid choice"<<endl;
        }
    }
}