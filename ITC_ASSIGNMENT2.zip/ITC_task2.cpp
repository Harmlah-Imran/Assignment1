#include <iostream>
using namespace std;
int main()
{
    cout << "Welcome to Library Management System" << endl;
    int option, book;
    string book_1 = "The Catcher in the Rye";//initializing the books
    string book_2 = "1984";
    string book_3 = "To Kill a Mockingbird";
    string book_4 = "he Great Gatsby";
    string book_5 = "Moby Dick";

    int copies_1 = 6;
    int copies_2 = 9;
    int copies_3 = 7;
    int copies_4 = 0;
    int copies_5 = 3;

    bool borrowed_1 = false;//bool expression to check if the books have been borrowed
    bool borrowed_2 = false;
    bool borrowed_3 = false;
    bool borrowed_4 = false;
    bool borrowed_5 = false;
    while (true)//while loop so the main menu displays until user exits
    {
        cout << "Please select an option:" << endl;
        cout << "1. Borrow a book" << endl;
        cout << "2. Return a book" << endl;
        cout << "3. Exit" << endl;
        cin >> option;

        if (option == 1) { 
            cout << "Please select a book you want to borrow:" << endl;
            cout << "1. " << book_1 << " (" << copies_1 << " copies available)"
                << endl;
            cout << "2. " << book_2 << " (" << copies_2 << " copies available)"
                << endl;
            cout << "3. " << book_3 << " (" << copies_3 << " copies available)"
                << endl;
            cout << "4. " << book_4 << " (" << copies_4 << " copies available)"
                << endl;
            cout << "5. " << book_5 << " (" << copies_5 << " copies available)"
                << endl;
            cin >> book;
            if (book == 1) {
                if (borrowed_1) {
                    cout << "You have already borrowed this book" << endl;
                }
                else if (copies_1 == 0) {
                    cout << "The book is unavailable" << endl;
                }
                else {
                    borrowed_1 = true;
                    copies_1--;
                    cout << "You have successfully borrowed"<< endl;
                }
            }
            else if (book == 2) {
                if (borrowed_2) {
                    cout << "You have already borrowed this book" << endl;
                }
                else if (copies_2 == 0) {
                    cout << "The book is unavailable" << endl;
                }
                else {
                    borrowed_2 = true;
                    copies_2--;
                    cout << "You have successfully borrowed" << endl;
                }
            }
            else if (book == 3) {
                if (borrowed_3) {
                    cout << "You have already borrowed this book " << endl;
                }
                else if (copies_3 == 0) {
                    cout << "The book is unavailable" << endl;
                }
                else {
                    borrowed_3 = true;
                    copies_3--;
                    cout << "You have successfully borrowed" << endl;
                }
            }
            else if (book == 4) {
                if (borrowed_4) {
                    cout << "You have already borrowed this book" << endl;
                }
                else if (copies_4 == 0) {
                    cout << "The book is unavailable" << endl;
                }
                else {
                    borrowed_4 = true;
                    copies_4--;
                    cout << "You have successfully borrowed "<< endl;
                }
            }
            else if (book == 5) {
                if (borrowed_5) {
                    cout << "You have already borrowed this book" << endl;
                }
                else if (copies_5 == 0) {
                    cout << "The book is unavailable" << endl;
                }
                else {
                    borrowed_5 = true;
                    copies_5--;
                    cout << "You have successfully borrowed"<< endl;
                }
            }
            else {
                cout << "Invalid input" << endl;
            }

        }
        else if (option == 2) {
            cout << "select a book that you want to return:" << endl;
            if (borrowed_1)
                cout << "1. " << book_1 << endl;
            if (borrowed_2)
                cout << "2. " << book_2 << endl;
            if (borrowed_3)
                cout << "3. " << book_3 << endl;
            if (borrowed_4)
                cout << "4. " << book_4 << endl;
            if (borrowed_5)
                cout << "5. " << book_5 << endl;

            int book;
            cin >> book;
            if (book == 1 && borrowed_1) {
                borrowed_1 = false;
                copies_1++;
                cout << "You have successfully returned" << endl;
            }
            else if (book == 2 && borrowed_2) {
                borrowed_2 = false;
                copies_2++;
                cout << "You have successfully returned"<< endl;
            }
            else if (book == 3 && borrowed_3) {
                borrowed_3 = false;
                copies_3++;
                cout << "You have successfully returned "<< endl;
            }
            else if (book == 4 && borrowed_4) {
                borrowed_4 = false;
                copies_4++;
                cout << "You have successfully returned" << endl;
            }
            else if (book == 5 && borrowed_5) {
                borrowed_5 = false;
                copies_5++;
                cout << "You have successfully returned " << endl;
            }
            else {
                cout << "invalid input" << endl;
            }

        }
        else if (option == 3) { 
            cout << "Exiting";
            break;
        }
        else {
            cout << "Invalid input" << endl;
        }
    }
    return 0;
}